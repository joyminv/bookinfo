#! /bin/bash

already_run=`ps -ef| grep "python productpage"| grep -v grep | wc -l`
if [ ${already_run} -ne 0 ];then
	echo "productpage service is already Running!!!! Stop it first"
	exit -1
fi

nohup python productpage.py 9080 &