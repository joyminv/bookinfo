#!/bin/bash

pid=`ps -ef| grep "python productpage"| grep -v grep |awk '{print $2}'`
kill -SIGTERM $pid
echo "process ${pid} killed"
echo "Sevice now stoped"
